from django import forms
from .models import Dosen


class DosenForm(forms.ModelForm):
    class Meta:
        model = Dosen
        fields = ['nama', 'nidn', 'email', 'no_hp', 'alamat', 'homebase', 'mahasiswa'] 
