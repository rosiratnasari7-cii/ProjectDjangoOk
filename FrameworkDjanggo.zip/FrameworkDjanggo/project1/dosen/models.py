from django.db import models
from mahasiswa.models import Mahasiswa

class Dosen(models.Model):
    nama = models.CharField(max_length=100)
    nidn = models.CharField(max_length=20, unique=True)
    email = models.EmailField()
    no_hp = models.CharField(max_length=15, blank=True)
    alamat = models.TextField(blank=True)
    homebase = models.CharField(max_length=100)

    # 🔥 RELASI DOSEN ↔ MAHASISWA
    mahasiswa = models.ManyToManyField(
        Mahasiswa,
        related_name='dosen',
        blank=True
    )

    def __str__(self):
        return self.nama
