from django.urls import path
from . import views

urlpatterns = [
    path('', views.input_dosen, name='input_dosen'),
    path('edit/<int:pk>/', views.edit_dosen, name='edit_dosen'),
    path('delete/<int:pk>/', views.dosen_delete, name='dosen_delete'),
    path('dosen/export/csv/', views.export_dosen_csv, name='export_dosen_csv'),
]
