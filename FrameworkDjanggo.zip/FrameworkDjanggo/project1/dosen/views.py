import csv
from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from .forms import DosenForm
from .models import Dosen


@login_required(login_url='/admin/login/')
def input_dosen(request):
    if request.method == 'POST':
        form = DosenForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('input_dosen')
    else:
        form = DosenForm()

    # Relasi ke Mata Kuliah
    semua_dosen = Dosen.objects.prefetch_related('matakuliah')

    return render(request, 'dosen/input.html', {
        'form': form,
        'semua_dosen': semua_dosen
    })


@login_required(login_url='/admin/login/')
def edit_dosen(request, pk):
    dosen = get_object_or_404(Dosen, pk=pk)

    if request.method == 'POST':
        form = DosenForm(request.POST, instance=dosen)
        if form.is_valid():
            form.save()
            return redirect('input_dosen')
    else:
        form = DosenForm(instance=dosen)

    return render(request, 'dosen/edit.html', {
        'form': form,
        'dosen': dosen
    })


@login_required(login_url='/admin/login/')
def dosen_delete(request, pk):
    dosen = get_object_or_404(Dosen, pk=pk)
    if request.method == 'POST':
        dosen.delete()
        return redirect('input_dosen')


@login_required(login_url='/admin/login/')
def export_dosen_csv(request):
    response = HttpResponse(
        content_type='text/csv; charset=utf-8-sig'
    )
    response['Content-Disposition'] = 'attachment; filename="data_dosen.csv"'

    writer = csv.writer(response, delimiter=';')
    writer.writerow(['ID', 'Nama Dosen', 'NIDN', 'Email', 'Homebase', 'Mata Kuliah'])

    semua_dosen = Dosen.objects.prefetch_related('matakuliah')

    for dosen in semua_dosen:
        mata_kuliah = ", ".join(
            [mk.nama_mk for mk in dosen.matakuliah.all()]
        )
        writer.writerow([
            dosen.id,
            dosen.nama,
            dosen.nidn,
            dosen.email,
            dosen.homebase,
            mata_kuliah
        ])

    return response
