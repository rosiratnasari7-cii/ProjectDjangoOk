from django.db import models
from mahasiswa.models import Mahasiswa
from dosen.models import Dosen

class MataKuliah(models.Model):
    nama_mk = models.CharField(max_length=100)
    kode_mk = models.CharField(max_length=10, unique=True)
    sks = models.IntegerField()
    semester = models.IntegerField()

    dosen = models.ForeignKey(
        Dosen,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='matakuliah'
    )

    mahasiswa = models.ManyToManyField(
        Mahasiswa,
        blank=True,
        related_name='matakuliah'
    )

    def __str__(self):
        return f"{self.nama_mk} ({self.kode_mk})"
