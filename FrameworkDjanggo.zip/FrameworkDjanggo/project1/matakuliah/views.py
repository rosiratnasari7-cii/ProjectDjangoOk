import csv
import json
from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.db.models import Count

from .forms import MataKuliahForm
from .models import MataKuliah


# =======================
# INPUT MATA KULIAH
# =======================
@login_required(login_url='/admin/login/')
def input_matakuliah(request):
    if request.method == 'POST':
        form = MataKuliahForm(request.POST)
        if form.is_valid():
            mk = form.save(commit=False)
            mk.save()
            form.save_m2m()   # WAJIB UNTUK MANY TO MANY
            return redirect('input_matakuliah')
    else:
        form = MataKuliahForm()

    semua_matakuliah = MataKuliah.objects.all()

    data_grafik = MataKuliah.objects.annotate(
        jumlah_mahasiswa=Count('mahasiswa')
    ).order_by('nama_mk')

    labels = [mk.nama_mk for mk in data_grafik]
    values = [mk.jumlah_mahasiswa for mk in data_grafik]

    return render(request, 'matakuliah/input.html', {
        'form': form,
        'semua_matakuliah': semua_matakuliah,
        'labels': json.dumps(labels),
        'values': json.dumps(values),
    })


# =======================
# EDIT MATA KULIAH
# =======================
@login_required(login_url='/admin/login/')
def edit_matakuliah(request, pk):
    mk = get_object_or_404(MataKuliah, pk=pk)

    if request.method == 'POST':
        form = MataKuliahForm(request.POST, instance=mk)
        if form.is_valid():
            form.save()
            return redirect('input_matakuliah')
    else:
        form = MataKuliahForm(instance=mk)

    return render(request, 'matakuliah/edit.html', {
        'form': form,
        'mk': mk
    })


# =======================
# DELETE MATA KULIAH
# =======================
@login_required(login_url='/admin/login/')
def matakuliah_delete(request, pk):
    mk = get_object_or_404(MataKuliah, pk=pk)
    if request.method == 'POST':
        mk.delete()
        return redirect('input_matakuliah')


# =======================
# EXPORT CSV
# =======================
@login_required(login_url='/admin/login/')
def export_matakuliah_csv(request):
    response = HttpResponse(
        content_type='text/csv; charset=utf-8-sig'
    )
    response['Content-Disposition'] = 'attachment; filename="data_matakuliah.csv"'

    writer = csv.writer(response, delimiter=';')
    writer.writerow([
        'ID',
        'Kode Mata Kuliah',
        'Nama Mata Kuliah',
        'SKS',
        'Semester',
        'Dosen Pengampu',
        'Jumlah Mahasiswa'
    ])

    semua_mk = MataKuliah.objects.annotate(
        jumlah_mahasiswa=Count('mahasiswa')
    ).select_related('dosen')

    for mk in semua_mk:
        writer.writerow([
            mk.id,
            mk.kode_mk,
            mk.nama_mk,
            mk.sks,
            mk.semester,
            mk.dosen.nama if mk.dosen else '-',
            mk.jumlah_mahasiswa
        ])

    return response
