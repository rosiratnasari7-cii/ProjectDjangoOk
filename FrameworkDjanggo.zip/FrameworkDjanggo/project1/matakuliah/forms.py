from django import forms
from .models import MataKuliah


class MataKuliahForm(forms.ModelForm):
    class Meta:
        model = MataKuliah
        fields = [
            'nama_mk',
            'kode_mk',
            'sks',
            'semester',
            'dosen',
            'mahasiswa',   # ⬅️ INI KUNCI UTAMA
        ]

        labels = {
            'nama_mk': 'Nama Mata Kuliah',
            'kode_mk': 'Kode Mata Kuliah',
            'sks': 'SKS',
            'semester': 'Semester',
            'dosen': 'Dosen Pengampu',
            'mahasiswa': 'Mahasiswa Pengambil Mata Kuliah',
        }

        widgets = {
            'nama_mk': forms.TextInput(attrs={'class': 'form-control'}),
            'kode_mk': forms.TextInput(attrs={'class': 'form-control'}),
            'sks': forms.NumberInput(attrs={'class': 'form-control'}),
            'semester': forms.NumberInput(attrs={'class': 'form-control'}),
            'dosen': forms.Select(attrs={'class': 'form-select'}),
            'mahasiswa': forms.SelectMultiple(
                attrs={'class': 'form-select'}
            ),  # ⬅️ multiple select
        }
