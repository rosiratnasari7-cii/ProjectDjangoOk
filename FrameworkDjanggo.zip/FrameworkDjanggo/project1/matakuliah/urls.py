from django.urls import path
from . import views

urlpatterns = [
    path('', views.input_matakuliah, name='input_matakuliah'),
    path('edit/<int:pk>/', views.edit_matakuliah, name='edit_matakuliah'),
    path('delete/<int:pk>/', views.matakuliah_delete, name='matakuliah_delete'),
    path('matakuliah/export/csv/', views.export_matakuliah_csv, name='export_matakuliah_csv'),
]
