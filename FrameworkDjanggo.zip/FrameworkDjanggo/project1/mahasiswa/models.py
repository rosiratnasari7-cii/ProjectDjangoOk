from django.db import models

class Mahasiswa(models.Model):
    nama = models.CharField(max_length=100)
    npm = models.CharField(max_length=20)

    JURUSAN_CHOICES = [
        ('TI', 'Teknologi Informasi'),
        ('SI', 'Sistem Informasi'),
        ('PI', 'Pendidikan Informatika'),
        ('PM', 'Pendidikan Matematika'),
        ('SD', 'Sains Data'),
    ]

    jurusan = models.CharField(max_length=50, choices=JURUSAN_CHOICES)
    email = models.EmailField()
    no_hp = models.CharField(max_length=15, default='-')
    alamat = models.CharField(max_length=255, default='-')

    def __str__(self):
        return f"{self.nama} ({self.npm})"
