from django import forms
from .models import Mahasiswa


class MahasiswaForm(forms.ModelForm):
    class Meta:
        model = Mahasiswa
        fields = ['nama', 'npm', 'jurusan', 'email', 'no_hp', 'alamat']

def clean(self):
        cleaned_data = super().clean()
        nama = cleaned_data.get('nama')
        no_hp = cleaned_data.get('no_hp')

        # Standarisasi nama menjadi huruf kapital
        if nama:
            cleaned_data['nama'] = nama.upper()

        # Membersihkan format nomor HP
        if no_hp:
            cleaned_data['no_hp'] = no_hp.replace(" ", "").replace("-", "")

        return cleaned_data
