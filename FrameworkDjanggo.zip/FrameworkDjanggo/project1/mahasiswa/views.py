from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
import csv

from django.db.models import Count  # ⬅ tambahan (TIDAK MENGUBAH KODE LAMA)

from .forms import MahasiswaForm
from .models import Mahasiswa


# =======================
# INPUT MAHASISWA
# =======================
@login_required(login_url='/admin/login/')
def input_mahasiswa(request):
    if request.method == 'POST':
        form = MahasiswaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('input_mahasiswa')
    else:
        form = MahasiswaForm()

    semua_mahasiswa = Mahasiswa.objects.all()

    return render(request, 'mahasiswa/input.html', {
        'form': form,
        'semua_mahasiswa': semua_mahasiswa
    })


# =======================
# EDIT MAHASISWA
# =======================
@login_required(login_url='/admin/login/')
def edit_mahasiswa(request, pk):
    mahasiswa = get_object_or_404(Mahasiswa, pk=pk)

    if request.method == 'POST':
        form = MahasiswaForm(request.POST, instance=mahasiswa)
        if form.is_valid():
            form.save()
            return redirect('input_mahasiswa')
    else:
        form = MahasiswaForm(instance=mahasiswa)

    return render(request, 'mahasiswa/edit.html', {
        'form': form,
        'mahasiswa': mahasiswa
    })


# =======================
# DELETE MAHASISWA
# =======================
@login_required(login_url='/admin/login/')
def mahasiswa_delete(request, pk):
    mahasiswa = get_object_or_404(Mahasiswa, pk=pk)
    if request.method == 'POST':
        mahasiswa.delete()
        return redirect('input_mahasiswa')


# =======================
# EXPORT MAHASISWA CSV
# =======================
@login_required(login_url='/admin/login/')
def export_mahasiswa_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="data_mahasiswa.csv"'

    writer = csv.writer(response, delimiter=';')
    writer.writerow(['ID', 'Nama', 'NIM', 'Jurusan', 'No HP', 'Email', 'Alamat'])

    for mhs in Mahasiswa.objects.all():
        writer.writerow([
            mhs.id,
            mhs.nama,
            mhs.npm,
            mhs.jurusan,
            mhs.no_hp,
            mhs.email,
            mhs.alamat
        ])

    return response




