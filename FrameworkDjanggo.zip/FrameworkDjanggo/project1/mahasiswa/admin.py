from django.contrib import admin
from .models import Mahasiswa


@admin.register(Mahasiswa)
class MahasiswaAdmin(admin.ModelAdmin):
    list_display = ('id', 'nama', 'npm', 'jurusan', 'email', 'no_hp', 'alamat')
    search_fields = ('nama', 'npm', 'email')
    list_filter = ('jurusan',)
    ordering = ('-id',)
