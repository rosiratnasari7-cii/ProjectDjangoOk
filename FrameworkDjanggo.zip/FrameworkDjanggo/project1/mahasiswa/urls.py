from django.urls import path
from . import views

urlpatterns = [
    path('', views.input_mahasiswa, name='input_mahasiswa'),
    path('mahasiswa/edit/<int:pk>/', views.edit_mahasiswa, name='edit_mahasiswa'),
    path('mahasiswa/delete/<int:pk>/', views.mahasiswa_delete, name='mahasiswa_delete'),
    path('export/', views.export_mahasiswa_csv, name='export_mahasiswa_csv'),

]
